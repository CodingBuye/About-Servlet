package servlet;

import entity.User;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class LoginServlet extends HttpServlet {

    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException{
        doPost(request, response);
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException{
        User user = new User();
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        user.setUsername(username);
        user.setPassword(password);

        if (user.getUsername().equals("admin") && user.getPassword().equals("admin")){
            request.getRequestDispatcher("/login_success.jsp").forward(request, response);
        }else {
            response.sendRedirect(request.getContextPath()+"/login_failure.jsp");
        }
    }
}
