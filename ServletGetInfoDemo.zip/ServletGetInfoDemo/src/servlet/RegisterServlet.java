package servlet;

import entity.Users;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class RegisterServlet extends HttpServlet {
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException{
        doPost(request, response);
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException{
        request.setCharacterEncoding("utf-8");
        Users users=new Users();
        String username, password, sex,email,introduce;
        Date birthday;
//        boolean flag;
        String[] hobbies;

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        try {
            username = request.getParameter("username");
            password = request.getParameter("password");
            sex = request.getParameter("sex");
            email = request.getParameter("email");
            introduce = request.getParameter("introduce");

            birthday = sdf.parse(request.getParameter("birthday"));
            //用来获取多个复选按钮的值
            hobbies = request.getParameterValues("hobbies");
            if (request.getParameterValues("flag")!=null){
                users.setFlag(true);
            }else {
                users.setFlag(false);
            }
            users.setUsername(username);
            users.setPassword(password);
            users.setSex(sex);
            users.setEmail(email);
            users.setIntroduce(introduce);
            users.setBirthday(birthday);
            users.setHobbies(hobbies);
            //把注册成功的用户对象保存在Session中
            request.getSession().setAttribute("registerUser",users);
            //跳转注册成功页面
            request.getRequestDispatcher("../userinfo.jsp").forward(request,response);
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
