package servlet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class TestServlet1 extends HttpServlet {
    public TestServlet1(){
        System.out.println("TestServlet1构造方法被执行......");
    }

    public void destroy(){
        System.out.println("TestServlet1销毁方法被执行......");
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException,IOException{
        System.out.println("TestServlet1的doGet方法被执行......");
        response.setContentType("text/html;chartset=utf-8");
        PrintWriter out = response.getWriter();
        out.println("<b>Hello world!</b>");

    }

    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException,IOException{
        System.out.println("TestServlet1的doPost方法被执行......");
        doGet(request, response);//让doPost与doGet执行相同的操作
    }

    public void init() throws ServletException{
        System.out.println("TestServlet1的初始化方法被执行......");
    }
}
