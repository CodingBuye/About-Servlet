package servlet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class TestServlet extends HttpServlet {

    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setCharacterEncoding("utf-8");
        doPost(request, response);
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException,IOException{
        //请求重定向方式跳转到test.jsp
        //当前路径：ServletPathDirection/servlet/
        //使用request.getContextPath()获得上下文对象
        response.sendRedirect(request.getContextPath()+"/test.jsp");

        //服务器内部跳转,这里的斜线表示项目的根目录
        request.getRequestDispatcher("/test.jsp").forward(request,response);
        //这种写法也是对的：
        request.getRequestDispatcher("../test.jsp").forward(request,response);
    }
}
